import React, { Component } from 'react'

export default class Whale extends Component {
	render() {
		return (
			<div>
				<ul>
					<li>Ali</li>
					<li>Ahmed</li>
					<li>Mohammed</li>
				</ul>
			</div>
		)
	}
}
